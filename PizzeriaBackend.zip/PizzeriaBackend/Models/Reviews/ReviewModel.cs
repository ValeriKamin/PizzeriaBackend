﻿namespace PizzeriaBackend.Models.Reviews
{
    public class ReviewModel
    {
        public string Name { get; set; }
        public string Topic { get; set; }
        public string Comment { get; set; }
        public string PhoneNumber { get; set; }
    }
}
