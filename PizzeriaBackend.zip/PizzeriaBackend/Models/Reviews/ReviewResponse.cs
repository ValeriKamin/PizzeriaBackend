﻿namespace PizzeriaBackend.Models.Reviews
{
    public class ReviewResponse
    {
        public string Message { get; set; }
    }
}
