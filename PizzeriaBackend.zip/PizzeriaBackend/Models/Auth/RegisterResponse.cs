﻿namespace PizzeriaBackend.Models.Auth
{
    public class RegisterResponse
    {
        public string Message { get; set; }
    }
}
